// 主题色轮盘 —— theme.write 令牌覆盖演示
var palette = ["#429CF5", "#34C77B", "#F2994A", "#B75DFF", "#EF4478"];
var idx = 0;

prisma.log("accent-roulette loaded");

prisma.on("gameExit", function () {
    idx = (idx + 1) % palette.length;
    var ok = prisma.setThemeTokens({ accent: palette[idx] });
    prisma.log("accent -> " + palette[idx] + " : " + ok);
    if (ok) {
        prisma.toast("主题色已轮换");
    }
});

prisma.on("launcherBoot", function () {
    // 恢复记忆：上次轮到哪一档（存插件私有目录会绕开本插件声明的权限面，
    // 这里用会话内存即可——每次启动器重启从头轮）。
    prisma.log("accent-roulette ready, palette size " + palette.length);
});
