// 启动横幅 —— gameLaunch / gameExit 事件演示
prisma.log("launch-banner loaded");

prisma.on("gameLaunch", function (e) {
    prisma.toast(e.version ? ("正在启动 " + e.version) : "正在启动 Minecraft");
});

prisma.on("gameExit", function (e) {
    prisma.toast(e.code === 0 ? "游戏已退出，欢迎回来" : ("游戏已退出（代码 " + e.code + "）"));
});
