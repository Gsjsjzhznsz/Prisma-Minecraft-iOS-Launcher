// 日落主题包 —— theme.write + ui 贡献行演示（Task329 内置四件套）
// 令牌键名 = PrismaTheme 白名单（accent/canvas/card/cardElevated/stroke/
// textPrimary/textSecondary/textTertiary/danger/success/warning）。
var PALETTES = [
    { name: "日落", accent: "#FF8A5C", canvas: "#241A16", card: "#33241D",
      cardElevated: "#3D2B22", stroke: "#5A3E30", textPrimary: "#F5EDE7",
      textSecondary: "#D9C3B5", textTertiary: "#A98F80" },
    { name: "森林", accent: "#7BC47F", canvas: "#16211A", card: "#1F2E24",
      cardElevated: "#27392C", stroke: "#3C5546", textPrimary: "#EDF5EE",
      textSecondary: "#C4D9C7", textTertiary: "#8FA895" },
    { name: "海洋", accent: "#5CC8FF", canvas: "#141E2A", card: "#1C2B3D",
      cardElevated: "#243649", stroke: "#37516D", textPrimary: "#EAF3FB",
      textSecondary: "#BFD6E8", textTertiary: "#8AA5BC" },
    { name: "玫瑰", accent: "#F472B6", canvas: "#241620", card: "#331E2C",
      cardElevated: "#3E2536", stroke: "#5C3A4E", textPrimary: "#F9EDF4",
      textSecondary: "#E3C4D4", textTertiary: "#B08FA2" },
];
var IDX_KEY = "palette-index";
var idx = 0;
try {
    var raw = prisma.readFile(IDX_KEY);
    if (raw !== null && raw !== undefined) {
        var p = parseInt(raw, 10);
        if (!isNaN(p) && p >= 0 && p < PALETTES.length) idx = p;
    }
} catch (e) {}

function apply(i, silent) {
    var pal = PALETTES[i];
    if (!prisma.isGranted("theme.write")) {
        if (!silent) prisma.toast("换肤被拒绝（请在插件详情页授权主题令牌）");
        return false;
    }
    if (!prisma.setThemeTokens(tokensOf(pal))) {
        if (!silent) prisma.toast("换肤被拒绝");
        return false;
    }
    return true;
}
function tokensOf(p) {
    return { accent: p.accent, canvas: p.canvas, card: p.card,
             cardElevated: p.cardElevated, stroke: p.stroke,
             textPrimary: p.textPrimary, textSecondary: p.textSecondary,
             textTertiary: p.textTertiary };
}
function refresh() {
    prisma.updateRow("sunset", { detail: "当前配色：" + PALETTES[idx].name + "（点击切换）" });
}

prisma.registerRow({
    id: "sunset",
    title: "日落主题包",
    detail: "当前配色：（点击切换）",
    onTap: function () {
        idx = (idx + 1) % PALETTES.length;
        if (apply(idx)) {
            prisma.writeFile(IDX_KEY, String(idx));
            prisma.toast("主题 → " + PALETTES[idx].name);
        }
        refresh();
    }
});
// 启动即恢复上次配色（静默：未授权时零打扰，授权后下次启动生效）。
apply(idx, true);
refresh();
prisma.log("theme-sunset ready (palette " + idx + ")");
