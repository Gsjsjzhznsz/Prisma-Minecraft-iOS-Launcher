// Modrinth 热门榜 —— network + ui 弹窗演示（Task329 内置四件套）
var API = "https://api.modrinth.com/v2/search?limit=5&index=downloads";

function fmt(n) {
    if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
    if (n >= 1000) return (n / 1000).toFixed(1) + "K";
    return String(n);
}

prisma.registerRow({
    id: "hot5",
    title: "Modrinth 热门榜",
    detail: "点击拉取下载量前五模组",
    onTap: function () {
        if (!prisma.isGranted("network")) {
            prisma.toast("请先在插件详情页授权联网");
            return;
        }
        prisma.updateRow("hot5", { detail: "正在拉取…" });
        prisma.httpGet(API, function (body) {
            if (!body) {
                prisma.updateRow("hot5", { detail: "拉取失败（检查网络/授权）" });
                prisma.toast("Modrinth 拉取失败");
                return;
            }
            try {
                var data = JSON.parse(body);
                var hits = (data && data.hits) ? data.hits : [];
                if (!hits.length) {
                    prisma.updateRow("hot5", { detail: "暂无数据" });
                    return;
                }
                var lines = "";
                for (var i = 0; i < hits.length && i < 5; i++) {
                    lines += (i + 1) + ". " + hits[i].title +
                             "（" + fmt(hits[i].downloads) + " 下载）\n";
                }
                prisma.updateRow("hot5", { detail: "上次更新：No.1 " + hits[0].title });
                prisma.alert("Modrinth 热门榜（下载量 Top5）", lines.trim());
            } catch (e) {
                prisma.updateRow("hot5", { detail: "解析失败" });
                prisma.warn("parse: " + e);
            }
        });
    }
});
prisma.log("modrinth-hot ready");
