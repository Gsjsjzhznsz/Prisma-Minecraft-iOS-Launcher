// 渲染器体检 —— 渲染器白名单 API 演示（只读 + 白名单内写入）
prisma.log("renderer-guard loaded");

prisma.on("launcherBoot", function () {
    var cur = prisma.getRenderer();
    prisma.log("current renderer = " + cur);
    if (cur && prisma.isRendererAvailable(cur)) {
        prisma.log("renderer OK, nothing to do");
        return;
    }
    // 当前渲染器不在候选表 / dylib 缺失 → 回落 auto（MCDL 存量值同款语义）
    var ok = prisma.setRenderer("auto");
    prisma.log("renderer unavailable -> fallback auto: " + ok);
    if (ok) {
        prisma.toast("渲染器不可用，已回落自动");
    }
});
