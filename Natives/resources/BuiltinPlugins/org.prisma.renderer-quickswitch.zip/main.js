// 渲染器快切 —— renderer.read/write + ui 贡献行演示（Task329 内置四件套）
function current() {
    var r = prisma.getRenderer();
    return r ? r : "auto";
}

function refresh() {
    prisma.updateRow("quickswitch", { detail: "当前：" + current() + "（点击切换）" });
}

prisma.registerRow({
    id: "quickswitch",
    title: "渲染器快切",
    detail: "当前：auto（点击切换）",
    onTap: function () {
        if (!prisma.isGranted("renderer.write")) {
            prisma.toast("请先在插件详情页授权渲染器写入");
            refresh();
            return;
        }
        var opts = prisma.listRendererOptions() || [];
        if (!opts.length) { prisma.toast("候选渲染器为空"); return; }
        var cur = current();
        var idx = -1;
        for (var i = 0; i < opts.length; i++) {
            if (opts[i].key === cur) { idx = i; break; }
        }
        // 从当前位置向后找第一个可用候选（循环；找不到可用 = 原值提示）。
        for (var step = 1; step <= opts.length; step++) {
            var cand = opts[(idx + step + opts.length) % opts.length];
            if (prisma.isRendererAvailable(cand.key)) {
                if (prisma.setRenderer(cand.key)) {
                    prisma.toast("渲染器 → " + cand.name);
                    refresh();
                } else {
                    prisma.toast("切换被拒绝（检查授权/白名单）");
                }
                return;
            }
        }
        prisma.toast("没有可用的其他渲染器");
    }
});
refresh();
prisma.log("renderer-quickswitch ready");
