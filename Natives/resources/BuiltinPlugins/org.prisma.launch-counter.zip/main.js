// 启动计数器 —— files.plugin 私有目录读写演示
var FILE = "counter.txt";

prisma.log("launch-counter loaded");

prisma.on("launcherBoot", function () {
    var n = 0;
    var raw = prisma.readFile(FILE);
    if (raw) {
        var parsed = parseInt(raw, 10);
        if (!isNaN(parsed)) n = parsed;
    }
    n = n + 1;
    var ok = prisma.writeFile(FILE, String(n));
    prisma.log("boot count " + n + " (saved: " + ok + ")");
    prisma.toast("第 " + n + " 次启动");
});
