// 启动统计 —— events + files.plugin + ui 贡献行演示（Task329 内置四件套）
var FILE = "stats.json";
var stats = { boots: 0, launches: 0, lastCode: -1 };
try {
    var raw = prisma.readFile(FILE);
    if (raw) {
        var p = JSON.parse(raw);
        if (p && typeof p === "object") {
            stats.boots = p.boots | 0;
            stats.launches = p.launches | 0;
            stats.lastCode = (p.lastCode === undefined ? -1 : p.lastCode);
        }
    }
} catch (e) {
    prisma.warn("stats parse failed, reset: " + e);
}

function save() { prisma.writeFile(FILE, JSON.stringify(stats)); }
function refresh() {
    prisma.updateRow("stats", {
        detail: "启动 " + stats.boots + " 次 · 游戏 " + stats.launches +
                " 次 · 最近退出码 " + stats.lastCode
    });
}

prisma.registerRow({
    id: "stats",
    title: "启动统计",
    detail: "启动 0 次 · 游戏 0 次",
    onTap: function () { refresh(); prisma.toast("启动统计已刷新"); }
});
prisma.on("launcherBoot", function () { stats.boots++; save(); refresh(); });
prisma.on("gameLaunch", function () { stats.launches++; save(); refresh(); });
prisma.on("gameExit", function (e) {
    stats.lastCode = (e && e.code !== undefined) ? e.code : -1;
    save(); refresh();
});
refresh();
prisma.log("launch-counter ready");
